#ifndef GEOH
#define GEOH
#include "ray.h"

using namespace std;

class material;

typedef struct hit_record {
	float t;
	vec3 p;
	vec3 nv;
} hit_record;

//geometry parent class
class hitable { 
public:
	virtual bool hit(const ray &r, float tmin, float tmax, hit_record &rec) const = 0;
};

class sphere : public hitable {
public:
	sphere() {}
	sphere(vec3 c, float r,vec3 _kd=vec3(1.0,1.0,1.0), float w_ri = 0.0f, float w_ti = 0.0f) : 
		center(c), radius(r), kd(_kd), w_r(w_ri), w_t(w_ti) {};
	virtual bool hit(const ray& r, float tmin, float tmax, hit_record& rec) const;
	
	vec3 center;
	float radius;
	vec3 kd;
	float w_r;//reflected
	float w_t;//transmitted
};

bool sphere::hit(const ray &r, float tmin, float tmax, hit_record & rec) const {
	/*
	To-do:
		compute whether the ray intersect the sphere
	*/
	vec3 oc = r.origin() - center;
    float a = dot(r.direction(), r.direction());
    float b = dot(oc, r.direction());
    float c = dot(oc, oc) - radius*radius;
    float discriminant = b*b - a*c;
    if (discriminant > 0) {
        float temp = (-b - sqrt(discriminant))/a;
        if (temp < tmax && temp > tmin) {
            rec.t = temp;
            rec.p = r.point_at_parameter(rec.t);
            rec.nv = (rec.p - center) / radius;
            return true;
        }
        temp = (-b + sqrt(discriminant)) / a;
        if (temp < tmax && temp > tmin) {
            rec.t = temp;
            rec.p = r.point_at_parameter(rec.t);
            rec.nv = (rec.p - center) / radius;
            return true;
        }
    }
    return false;
}

vec3 reflect(const vec3 &d, const vec3 &nv) {
	//compute the reflect direction
	//To-do
	return d - 2*dot(d, nv)*nv;

	//return vec3(0, 0, 0);
}

vec3 refract(const vec3& v, const vec3& n, float r) {
	//compute the refracted direction
	//To-do
	auto cos_theta = fmin(dot(-v, n), 1.0);
    vec3 r_out_perp =  r * (v + cos_theta*n);
    vec3 r_out_parallel = -sqrt(fabs(1.0 - r_out_perp.squared_length())) * n;
    return r_out_perp + r_out_parallel;
}

#endif
